/* Enhanced Dental Clinic — interactions (no dependencies) */
(function () {
  var doc = document.documentElement;
  var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var header = document.querySelector('.site-header');

  /* Header state on scroll */
  function onScroll() {
    var y = window.scrollY || 0;
    if (header) header.classList.toggle('scrolled', y > 24);
    if (!reduce && heroImg) heroImg.style.transform = 'translate3d(0,' + Math.min(y * 0.12, 140) + 'px,0)';
  }
  var heroImg = document.querySelector('.hero-media img');
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  /* Mobile menu */
  var btn = document.querySelector('.menu-btn');
  if (btn) {
    btn.addEventListener('click', function () {
      var open = doc.classList.toggle('menu-open');
      btn.setAttribute('aria-expanded', open ? 'true' : 'false');
      document.body.style.overflow = open ? 'hidden' : '';
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && doc.classList.contains('menu-open')) btn.click();
    });
  }

  /* Reveal on scroll — only for elements that start below the fold */
  if (!reduce && 'IntersectionObserver' in window) {
    var vh = window.innerHeight;
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) { en.target.classList.remove('pre'); io.unobserve(en.target); }
      });
    }, { rootMargin: '0px 0px -8% 0px' });
    document.querySelectorAll('.rv').forEach(function (el, i) {
      if (el.getBoundingClientRect().top > vh * 0.92) {
        el.classList.add('pre');
        el.style.transitionDelay = ((i % 3) * 0.08) + 's';
        io.observe(el);
      }
    });
  }

  /* Gentle page transition for internal links */
  if (!reduce) {
    document.addEventListener('click', function (e) {
      var a = e.target.closest && e.target.closest('a');
      if (!a || a.target === '_blank' || e.metaKey || e.ctrlKey || e.shiftKey) return;
      var href = a.getAttribute('href') || '';
      if (!href || href.charAt(0) === '#' || /^(https?:|mailto:|tel:|whatsapp:)/i.test(href)) return;
      e.preventDefault();
      document.body.classList.add('leaving');
      setTimeout(function () { window.location.href = a.href; }, 280);
    });
    window.addEventListener('pageshow', function () { document.body.classList.remove('leaving'); });
  }

  /* Booking form → WhatsApp message (nothing is stored or sent by this site) */
  var form = document.querySelector('form.book');
  if (form) {
    var ar = doc.lang === 'ar';
    var wa = form.getAttribute('data-wa');
    var out = document.querySelector('.result');
    var dateEl = form.querySelector('#date');
    if (dateEl) {
      var t = new Date(); t.setMinutes(t.getMinutes() - t.getTimezoneOffset());
      dateEl.min = t.toISOString().slice(0, 10);
    }
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var name = form.querySelector('#name').value.trim();
      var phone = form.querySelector('#phone').value.trim();
      var tx = form.querySelector('#treatment');
      var txt = tx.options[tx.selectedIndex].text;
      var date = dateEl.value;
      var notes = form.querySelector('#notes').value.trim();
      var err = form.querySelector('.err');
      var digits = phone.replace(/[^\d+]/g, '');
      if (name.length < 2) { err.textContent = ar ? 'من فضلك اكتب اسمك.' : 'Please enter your name.'; form.querySelector('#name').focus(); return; }
      if (digits.replace(/\D/g, '').length < 10) { err.textContent = ar ? 'من فضلك اكتب رقم موبايل صحيح.' : 'Please enter a valid mobile number.'; form.querySelector('#phone').focus(); return; }
      err.textContent = '';
      var msg = ar
        ? 'أهلاً، عايز أحجز ميعاد (من الموقع)\nالاسم: ' + name + '\nالموبايل: ' + phone + '\nالعلاج: ' + txt + (date ? '\nاليوم المفضل: ' + date : '') + (notes ? '\nملاحظات: ' + notes : '')
        : 'Hello, I would like to book an appointment (via website)\nName: ' + name + '\nMobile: ' + phone + '\nTreatment: ' + txt + (date ? '\nPreferred date: ' + date : '') + (notes ? '\nNotes: ' + notes : '');
      out.querySelector('pre').textContent = msg;
      out.querySelector('a.send').href = 'https://wa.me/' + wa + '?text=' + encodeURIComponent(msg);
      out.classList.add('show');
      out.scrollIntoView({ behavior: reduce ? 'auto' : 'smooth', block: 'center' });
      out.querySelector('a.send').focus({ preventScroll: true });
    });
  }

  /* Map loads only on request (faster page, no broken frame when maps are blocked) */
  document.querySelectorAll('.map[data-src] .show-map').forEach(function (b) {
    b.addEventListener('click', function () {
      var box = b.closest('.map'); var f = document.createElement('iframe');
      f.src = box.getAttribute('data-src'); f.title = 'Google Maps'; f.loading = 'lazy';
      f.referrerPolicy = 'no-referrer-when-downgrade'; box.appendChild(f); b.remove();
    });
  });

  /* Year */
  document.querySelectorAll('[data-year]').forEach(function (el) { el.textContent = new Date().getFullYear(); });
})();
